package com.springbootrest.springrest.services;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springbootrest.springrest.dao.CourseDao;
import com.springbootrest.springrest.models.Course;

@Service
public class CourseServiceImpl implements CoureseService{
	
	//Interface ==> {CourseDao} type er variable/referrence create korlam. 
	/*
	 * Autowired = spring will help me to create object
	 * "CourseDao" interface er object create kore 
	   "courseDao" variable er vitor inject korbe. So that courseDao variable becomes an object
	 * {CourseDao} is nothing but an interface implementing JPA Repository and defining entity/model {Course} 
	 * This is called spring dependency injection
	*/
	@Autowired
	private CourseDao courseDao;

	@Override
	public List<Course> getCourses() {
		return courseDao.findAll();
	}

	@Override
	public Course getCourse(long courseId) {
		return courseDao.getOne(courseId);
	}

	@Override
	public Course addCourse(Course course) {
		courseDao.save(course);
		return course; 
	}

	@Override
	public Course updateCourse(Course course, long courseId) {
		courseDao.save(course);
		return course;
	}

	@Override
	public void deleteCourse(long courseId) {
		Course c = getCourse(courseId);
		Course object = courseDao.getOne(courseId);
		courseDao.delete(object);
	}
	
}
