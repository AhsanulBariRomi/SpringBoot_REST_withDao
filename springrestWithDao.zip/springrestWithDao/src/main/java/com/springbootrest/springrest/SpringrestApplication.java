package com.springbootrest.springrest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceTransactionManagerAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;

import com.springbootrest.springrest.models.Course;

@SpringBootApplication
/* @EnableAutoConfiguration(exclude = {DataSourceAutoConfiguration.class, 
		DataSourceTransactionManagerAutoConfiguration.class, HibernateJpaAutoConfiguration.class}) */

public class SpringrestApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringrestApplication.class, args);
	}

}
/*
 HOW TO RUN:
 * STEP1: Right click on the project
 * STEP2: Run as - Java Application
 * STEP3: Choose "SpringrestApplication"
 * STEP4: Go to POST MAN and start hitting the URLs
*/
/*
 * To Get the course list.
 GET: {Base URL}/courses 
 * STEP1: Go to [Controller] and find ==> @GetMapping("/courses").
 * STEP2: Get into the method mapped with it. ==> getCourses()
 * STEP3: From this method it moves to [SERVICE LAYER] from [CONTROLLER].
 * STEP4: method {getCourses} in [SERVICE LAYER] goes to Dao Layer ==> [courseDao].==> findAll()
 *        courseDao is nothing but just a class extending JPA Repository and defining the entity/model {Course}
 *        and the primary key.
 * STEP5: [SERVICE LAYER] returns a course list to [CONTROLLER].
 * STEP6: [CONTORLLER] returns the course list to client.
*/

/*
 * To Get a single course using the id.
 GET: {Base URL}/course/{courseId} 
 * STEP1: Go to [Controller] and find ==> @GetMapping("/course/{courseId}").
 * STEP2: Get into the method mapped with it.
 * STEP3: From this method it moves to [SERVICE LAYER] from [CONTROLLER].
 * STEP4: method getCourses(long courseId) in [SERVICE LAYER] returns a course with the id.
*/

/*
 * To Add a new course.
 POST: {Base URL}/courses + A body containing a JSON object
 * STEP1: Go to [Controller] and find ==> @PostMapping("/courses").
 * STEP2: Get into the method mapped with it.
 * STEP3: From this method it moves to [SERVICE LAYER] from [CONTROLLER].
 * STEP4: method addCourse(Course course) in [SERVICE LAYER] adds the course into the list and 
 * 	      returns the added course data.
 * STEP5: Now call GET courses to check that the new course has been added to the list.   
*/

/*
 * To Update a course Information.
 PUT: {Base URL}/courses/{courseId} + A body containing a JSON object
 * STEP1: Go to [Controller] and find ==> @PutMapping("/course/{courseId}"). 
 * STEP2: Get into the method mapped with it.
 * STEP3: From this method it moves to [SERVICE LAYER] from [CONTROLLER].
 * STEP4: method updateCourse(Course course, long courseId) in [SERVICE LAYER] updates the course into the list and 
  	      returns the updated course data.
 * STEP5: Now call GET courses to check that the course has been updated in the list. 	      
*/

/*
 * To Delete a course Information.
 DELETE: {Base URL}/courses/{courseId}
 * STEP1: Go to [Controller] and find ==> @DeleteMapping("/courses/{courseId}"). 
 * STEP2: Get into the method mapped with it.
 * STEP3: From this method it moves to [SERVICE LAYER] from [CONTROLLER].
 * STEP4: method deleteCourse(long courseId) in [SERVICE LAYER] deletes the course into the list and 
  	      returns the deleted course data.
 * STEP5: Now call GET courses to check that the course has been deleted from the list. 	      
*/
 