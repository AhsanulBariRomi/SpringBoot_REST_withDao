package com.springbootrest.springrest.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springbootrest.springrest.models.Course;

//JpaRepository< [Model name], [Primary key type] >
@Repository
public interface CourseDao extends JpaRepository<Course, Long>{
	
}
